﻿using Microsoft.AspNetCore.Components;

namespace WinPass.UI;

public class AppUiBase : ComponentBase
{
}