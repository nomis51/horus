﻿namespace WinPass.UI.Components.Abstractions;

public class Page : Component
{
    
}